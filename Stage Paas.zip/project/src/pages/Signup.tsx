import React, { useState } from 'react';
import AuthLayout from '../components/AuthLayout';
import Input from '../components/Input';
import Button from '../components/Button';

export default function Signup() {
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // TODO: Implement signup logic
    setTimeout(() => setIsLoading(false), 1000);
  };

  return (
    <AuthLayout
      title="Create your account"
      subtitle="Join India's trusted ticket marketplace"
    >
      <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="First name"
              type="text"
              autoComplete="given-name"
              required
              placeholder="Enter first name"
            />
            <Input
              label="Last name"
              type="text"
              autoComplete="family-name"
              required
              placeholder="Enter last name"
            />
          </div>

          <Input
            label="Email address"
            type="email"
            autoComplete="email"
            required
            placeholder="Enter your email"
          />

          <Input
            label="Phone number"
            type="tel"
            autoComplete="tel"
            required
            placeholder="Enter phone number"
          />
          
          <Input
            label="Password"
            type="password"
            autoComplete="new-password"
            required
            placeholder="Create a password"
          />

          <Input
            label="Confirm Password"
            type="password"
            autoComplete="new-password"
            required
            placeholder="Confirm your password"
          />

          <div className="flex items-center">
            <input
              id="terms"
              name="terms"
              type="checkbox"
              required
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label htmlFor="terms" className="ml-2 block text-sm text-gray-900">
              I agree to the{' '}
              <a href="#" className="text-indigo-600 hover:text-indigo-500">
                Terms of Service
              </a>
              {' '}and{' '}
              <a href="#" className="text-indigo-600 hover:text-indigo-500">
                Privacy Policy
              </a>
            </label>
          </div>
        </div>

        <Button type="submit" isLoading={isLoading}>
          Create account
        </Button>

        <div className="text-center">
          <p className="text-sm text-gray-600">
            Already have an account?{' '}
            <a href="/login" className="font-medium text-indigo-600 hover:text-indigo-500">
              Sign in
            </a>
          </p>
        </div>
      </form>
    </AuthLayout>
  );
}
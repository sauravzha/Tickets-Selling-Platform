import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LogOut, Ticket, Search, Bell, Plus } from 'lucide-react';
import PaymentModal from '../components/PaymentModal';
import ListTicketModal from '../components/ListTicketModal';
import TicketList from '../components/TicketList';
import Footer from '../components/Footer';

const concerts = [
  {
    id: 1,
    title: "Karan Aujla - It Was All A Dream",
    location: "Jaipur International Stadium, Jaipur",
    price: 2999,
    image: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=500&auto=format&fit=crop&q=60",
    date: "25th May, 2024",
    background: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80"
  },
  {
    id: 2,
    title: "TRIBUTE TO COLDPLAY",
    location: "Phoenix Marketcity, Mumbai",
    price: 5999,
    image: "https://images.unsplash.com/photo-1524368535928-5b5e00ddc76b?w=500&auto=format&fit=crop&q=60",
    date: "15th June, 2024",
    background: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?auto=format&fit=crop&q=80"
  },
  {
    id: 3,
    title: "Shreya Ghoshal Live in Concert",
    location: "Nehru Stadium, Pune",
    price: 3999,
    image: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=500&auto=format&fit=crop&q=60",
    date: "30th June, 2024",
    background: "https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?auto=format&fit=crop&q=80"
  },
  {
    id: 4,
    title: "The Arijit Singh Concert",
    location: "DY Patil Stadium, Mumbai",
    price: 4999,
    image: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=500&auto=format&fit=crop&q=60",
    date: "10th July, 2024",
    background: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&q=80"
  }
];

// Sample tickets data
const sampleTickets = [
  {
    id: 1,
    section: "A",
    row: "1",
    seat: "12",
    price: 3500,
    seller: "John D.",
    rating: 4.8
  },
  {
    id: 2,
    section: "B",
    row: "3",
    seat: "15",
    price: 2999,
    seller: "Sarah M.",
    rating: 4.5
  },
  {
    id: 3,
    section: "A",
    row: "2",
    seat: "8",
    price: 4200,
    seller: "Raj P.",
    rating: 4.9
  }
];

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [selectedConcert, setSelectedConcert] = useState<number | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showListTicketModal, setShowListTicketModal] = useState(false);
  const [selectedTicketPrice, setSelectedTicketPrice] = useState(0);

  const handlePurchase = (ticket: any) => {
    setSelectedTicketPrice(ticket.price);
    setShowPaymentModal(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Ticket className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-indigo-600">Stage<span className="text-gray-900">PASS</span></span>
            </div>
            
            <div className="flex-1 flex items-center justify-center px-2 lg:ml-6 lg:justify-end">
              <div className="max-w-lg w-full lg:max-w-xs">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white/50 backdrop-blur-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Search for events or tickets"
                    type="search"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowListTicketModal(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
              >
                <Plus className="h-5 w-5" />
                <span>List Tickets</span>
              </button>
              <button className="p-2 rounded-full text-gray-400 hover:text-gray-500">
                <Bell className="h-6 w-6" />
              </button>
              <button
                onClick={() => logout()}
                className="p-2 text-gray-400 hover:text-gray-500"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main content */}
      <main className="flex-1 max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {/* Featured Events */}
        <div className="px-4 sm:px-0">
          <h2 className="text-2xl font-bold text-gray-900">Featured Events</h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {concerts.map((concert) => (
              <div
                key={concert.id}
                className="group relative bg-white overflow-hidden shadow-lg rounded-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02]"
                style={{
                  backgroundImage: `url(${concert.background})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center'
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent" />
                <div className="relative p-6 flex flex-col h-full min-h-[400px] justify-end">
                  <p className="text-white/90 text-sm font-medium mb-2">{concert.date}</p>
                  <h3 className="text-xl font-bold text-white mb-2">{concert.title}</h3>
                  <p className="text-white/80 text-sm mb-4">{concert.location}</p>
                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-white/60 text-xs">Starting from</p>
                      <span className="text-lg font-bold text-white">₹{concert.price.toLocaleString()}</span>
                    </div>
                    <button
                      onClick={() => setSelectedConcert(concert.id)}
                      className="px-4 py-2 bg-white text-indigo-600 rounded-md font-medium hover:bg-indigo-50 transition-colors"
                    >
                      View Tickets
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tickets Section */}
        {selectedConcert && (
          <div className="mt-8 px-4 sm:px-0">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Available Tickets</h3>
              <TicketList tickets={sampleTickets} onPurchase={handlePurchase} />
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        amount={selectedTicketPrice}
      />

      <ListTicketModal
        isOpen={showListTicketModal}
        onClose={() => setShowListTicketModal(false)}
        concertId={selectedConcert || 0}
      />
    </div>
  );
}
import React from 'react';
import { Tag } from 'lucide-react';

interface Ticket {
  id: number;
  section: string;
  row: string;
  seat: string;
  price: number;
  seller: string;
  rating: number;
}

interface TicketListProps {
  tickets: Ticket[];
  onPurchase: (ticket: Ticket) => void;
}

const TicketList: React.FC<TicketListProps> = ({ tickets, onPurchase }) => {
  return (
    <div className="space-y-4">
      {tickets.map((ticket) => (
        <div
          key={ticket.id}
          className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
        >
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center space-x-2">
                <Tag className="w-5 h-5 text-indigo-600" />
                <span className="font-medium">
                  Section {ticket.section}, Row {ticket.row}, Seat {ticket.seat}
                </span>
              </div>
              <div className="mt-2 text-sm text-gray-500">
                Seller: {ticket.seller} • Rating: {ticket.rating}/5
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-indigo-600">
                ₹{ticket.price.toLocaleString()}
              </div>
              <button
                onClick={() => onPurchase(ticket)}
                className="mt-2 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
              >
                Purchase
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TicketList;
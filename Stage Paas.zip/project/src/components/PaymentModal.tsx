import React, { useState } from 'react';
import { X, CreditCard, QrCode, Smartphone } from 'lucide-react';
import toast from 'react-hot-toast';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  sellerUpi?: string;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, amount, sellerUpi }) => {
  const [paymentMethod, setPaymentMethod] = useState<string>('');
  const [processing, setProcessing] = useState(false);

  if (!isOpen) return null;

  const handlePayment = async () => {
    setProcessing(true);
    try {
      const options = {
        key: "rzp_test_YOUR_KEY_HERE", // Replace with actual Razorpay key
        amount: amount * 100, // Razorpay expects amount in paise
        currency: "INR",
        name: "StagePASS",
        description: "Concert Ticket Purchase",
        handler: function (response: any) {
          toast.success("Payment successful! Payment ID: " + response.razorpay_payment_id);
          onClose();
        },
        prefill: {
          name: "Test User",
          email: "test@example.com",
          contact: "9999999999"
        },
        theme: {
          color: "#4F46E5"
        }
      };

      const paymentObject = new (window as any).Razorpay(options);
      paymentObject.open();
    } catch (error) {
      toast.error("Payment failed. Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  const paymentMethods = [
    {
      id: 'razorpay',
      name: 'Credit/Debit Card (Razorpay)',
      icon: <CreditCard className="w-6 h-6" />,
      processor: handlePayment
    },
    {
      id: 'paytm',
      name: 'Paytm',
      icon: <Smartphone className="w-6 h-6" />,
      processor: handlePayment
    },
    {
      id: 'upi',
      name: 'UPI Payment (PhonePe/Google Pay)',
      icon: <Smartphone className="w-6 h-6" />,
      fields: ['UPI ID']
    },
    {
      id: 'qr',
      name: 'Scan QR Code',
      icon: <QrCode className="w-6 h-6" />,
      fields: []
    }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-md w-full mx-4 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>
        
        <div className="p-6">
          <h2 className="text-2xl font-bold mb-4">Payment Details</h2>
          <p className="text-lg text-indigo-600 font-semibold mb-6">
            Amount: ₹{amount.toLocaleString()}
          </p>

          {sellerUpi && (
            <div className="mb-4 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">Seller's UPI ID:</p>
              <p className="font-medium">{sellerUpi}</p>
            </div>
          )}

          <div className="space-y-4">
            {paymentMethods.map((method) => (
              <button
                key={method.id}
                onClick={() => {
                  setPaymentMethod(method.id);
                  if (method.processor) {
                    method.processor();
                  }
                }}
                disabled={processing}
                className={`w-full p-4 rounded-lg border-2 flex items-center gap-4 transition-all ${
                  paymentMethod === method.id
                    ? 'border-indigo-600 bg-indigo-50'
                    : 'border-gray-200 hover:border-indigo-200'
                } ${processing ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {method.icon}
                <span className="font-medium">{method.name}</span>
              </button>
            ))}
          </div>

          {paymentMethod === 'qr' && (
            <div className="mt-6 flex flex-col items-center space-y-4">
              <div className="bg-white p-4 rounded-lg shadow-lg">
                <img
                  src="https://images.unsplash.com/photo-1614849963640-9cc74b2a826f?w=500&auto=format&fit=crop&q=60"
                  alt="QR Code"
                  className="w-48 h-48 object-cover rounded-lg"
                />
              </div>
              <p className="text-sm text-gray-600">
                Scan this QR code using any UPI app
              </p>
            </div>
          )}

          {paymentMethod === 'upi' && (
            <div className="mt-6">
              <input
                type="text"
                placeholder="Enter UPI ID (e.g., name@upi)"
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
              <button
                onClick={handlePayment}
                disabled={processing}
                className="w-full mt-4 bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50"
              >
                {processing ? 'Processing...' : 'Pay Now'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;
import React, { useState } from 'react';
import { X, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

interface ListTicketModalProps {
  isOpen: boolean;
  onClose: () => void;
  concertId: number;
}

const ListTicketModal: React.FC<ListTicketModalProps> = ({ isOpen, onClose, concertId }) => {
  const [ticketDetails, setTicketDetails] = useState({
    quantity: 1,
    pricePerTicket: '',
    section: '',
    row: '',
    seat: '',
    email: '',
    upiId: '',
    phoneNumber: '',
    ticketProof: null as File | null,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast.success('Tickets submitted for verification! We will contact you shortly.');
      onClose();
    } catch (error) {
      toast.error('Failed to submit tickets. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">List Your Tickets</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-yellow-400" />
              <p className="ml-3 text-sm text-yellow-700">
                Your tickets will be verified by our team before being listed. Please ensure all information is accurate.
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Number of Tickets
                </label>
                <input
                  type="number"
                  min="1"
                  value={ticketDetails.quantity}
                  onChange={(e) => setTicketDetails({ ...ticketDetails, quantity: parseInt(e.target.value) })}
                  className="w-full p-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Price per Ticket (₹)
                </label>
                <input
                  type="number"
                  value={ticketDetails.pricePerTicket}
                  onChange={(e) => setTicketDetails({ ...ticketDetails, pricePerTicket: e.target.value })}
                  className="w-full p-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter price per ticket"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Section
                </label>
                <input
                  type="text"
                  value={ticketDetails.section}
                  onChange={(e) => setTicketDetails({ ...ticketDetails, section: e.target.value })}
                  className="w-full p-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Row
                </label>
                <input
                  type="text"
                  value={ticketDetails.row}
                  onChange={(e) => setTicketDetails({ ...ticketDetails, row: e.target.value })}
                  className="w-full p-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Seat
                </label>
                <input
                  type="text"
                  value={ticketDetails.seat}
                  onChange={(e) => setTicketDetails({ ...ticketDetails, seat: e.target.value })}
                  className="w-full p-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={ticketDetails.email}
                  onChange={(e) => setTicketDetails({ ...ticketDetails, email: e.target.value })}
                  className="w-full p-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="For verification purposes"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={ticketDetails.phoneNumber}
                  onChange={(e) => setTicketDetails({ ...ticketDetails, phoneNumber: e.target.value })}
                  className="w-full p-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="For verification purposes"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                UPI ID (For receiving payments)
              </label>
              <input
                type="text"
                value={ticketDetails.upiId}
                onChange={(e) => setTicketDetails({ ...ticketDetails, upiId: e.target.value })}
                className="w-full p-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Enter your UPI ID"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Upload Ticket Proof
              </label>
              <input
                type="file"
                onChange={(e) => setTicketDetails({ ...ticketDetails, ticketProof: e.target.files?.[0] || null })}
                className="w-full p-2 border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                accept="image/*,.pdf"
                required
              />
              <p className="mt-1 text-sm text-gray-500">
                Please upload a clear image or PDF of your ticket(s) for verification
              </p>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Submitting...' : 'Submit for Verification'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ListTicketModal;
import React from 'react';
import { Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white/80 backdrop-blur-md border-t border-gray-200">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-sm text-gray-500">
            © 2024 StagePASS. All rights reserved.
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <span>Created by Saurav Jha</span>
            <span>•</span>
            <a
              href="mailto:jhasaurav562@mail.com"
              className="flex items-center space-x-1 text-indigo-600 hover:text-indigo-500"
            >
              <Mail className="h-4 w-4" />
              <span>jhasaurav562@mail.com</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
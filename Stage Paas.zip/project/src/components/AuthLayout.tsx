import React from 'react';
import { Ticket } from 'lucide-react';

interface AuthLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle: string;
}

export default function AuthLayout({ children, title, subtitle }: AuthLayoutProps) {
  return (
    <div className="min-h-screen flex">
      {/* Left side - Auth Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <div className="flex justify-center items-center space-x-2">
              <Ticket className="h-12 w-12 text-indigo-600" />
              <span className="text-3xl font-bold text-indigo-600">Stage<span className="text-gray-900">PASS</span></span>
            </div>
            <h2 className="mt-6 text-3xl font-extrabold text-gray-900">{title}</h2>
            <p className="mt-2 text-sm text-gray-600">{subtitle}</p>
          </div>
          {children}
        </div>
      </div>

      {/* Right side - Dynamic Background with Animation */}
      <div className="hidden lg:block lg:w-1/2 relative overflow-hidden">
        {/* Multiple layered background images for depth */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-indigo-800 to-blue-900 opacity-90" />
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1459749411175-04bf5292ceea?auto=format&fit=crop&q=80')] bg-cover bg-center mix-blend-overlay" />
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1524368535928-5b5e00ddc76b?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-30 animate-pulse" />
        </div>
        
        {/* Animated overlay patterns */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(76,29,149,0.1)_0%,rgba(76,29,149,0)_50%)] animate-pulse" />
        </div>
        
        {/* Floating particles effect */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-white/20 rounded-full"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animation: `float ${5 + Math.random() * 10}s linear infinite`,
                animationDelay: `${-Math.random() * 5}s`,
              }}
            />
          ))}
        </div>
        
        {/* Content */}
        <div className="relative z-20 h-full flex flex-col items-center justify-center p-8">
          <div className="text-center text-white space-y-6 max-w-lg">
            <h3 className="text-5xl font-bold tracking-tight animate-pulse">
              StagePASS
            </h3>
            <p className="text-xl font-medium text-gray-200">
              India's Premier Ticket Exchange Platform
            </p>
            <div className="space-y-2 text-gray-300">
              <p className="text-sm">✓ Secure Transactions</p>
              <p className="text-sm">✓ Verified Sellers</p>
              <p className="text-sm">✓ Instant Ticket Transfer</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}